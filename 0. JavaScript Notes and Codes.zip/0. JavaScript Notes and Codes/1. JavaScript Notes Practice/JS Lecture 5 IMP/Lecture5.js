// const sum = (a,b)=> {
//   return a+b;
// }

// console.log(sum(3,4));

// function returnNumberOfVowels(str) {
//   let count = 0;
//   for (let i=0;i<str.length;i++) {
//     if (
//       str[i] === "a" ||
//       str[i] === "e" ||
//       str[i] === "i" ||
//       str[i] === "o" ||
//       str[i] === "u" ||
//       str[i] === "A" ||
//       str[i] === "E" ||
//       str[i] === "I" ||
//       str[i] === "O" ||
//       str[i] === "U"
//     ) {
//       count++;
//     }
//   }
//   console.log(count);
// }

// const returnNumberOfVowels = (str) => {
//   let count = 0;
//   for (let i = 0; i < str.length; i++) {
//     if (
//       str[i] === "a" ||
//       str[i] === "e" ||
//       str[i] === "i" ||
//       str[i] === "o" ||
//       str[i] === "u" ||
//       str[i] === "A" ||
//       str[i] === "E" ||
//       str[i] === "I" ||
//       str[i] === "O" ||
//       str[i] === "U"
//     ) {
//       count++;
//     }
//   }
//   console.log(count);
// };
// returnNumberOfVowels(prompt("Enter a string :"));

// //foreach

// let arr = [1, 2, 3, 4, 5];

// arr.forEach((val,idx,arr) => {
//     console.log(val,idx,arr);
// })

// arr.forEach((val) => {
//     console.log(`square of ${val} = ${val*val}`);
// })

// console.log(arr);

// let newArr = arr.forEach((val) => {
//   return val * val;
// });

// console.log(newArr);

// //map

// let arr = [1,2,3,4,5];

// arr.map((val,idx,arr) => {
//     console.log(val,idx,arr);
// })

// console.log(arr);

// let newArr = arr.map((val) => {
//     return val*val
// })

// console.log(newArr);

// //filter

// let arr = [1,2,3,4,5];

// console.log(arr);

// let newArr = arr.filter((val) => {
//     return val%2===0
// })

// console.log(newArr);

// //reduce
// const arr1 = [1,2,3,4];

// const output = arr1.reduce((pre, curr)=>{
//  return pre+curr;}
// );
// console.log(output)

// //PQ1

// const marks = [67,36,97,85,66,90,95];

// let filteredMarks = marks.filter((val)=>{
//     if (val>=90){
//         return val;
//     }
// })

// console.log(filteredMarks);

// //PQ2

// let n = prompt("enter a number: ");

// let arr = [];

// for (let i = 1; i <= n; i++) {
//   arr[i - 1] = i;
// }

// console.log(arr);

// const sum = arr.reduce((pre, curr) => {
//   return pre + curr;
// });

// console.log(sum);

// const product = arr.reduce((pre, curr) => {
//   return pre * curr;
// });

// console.log(product);
