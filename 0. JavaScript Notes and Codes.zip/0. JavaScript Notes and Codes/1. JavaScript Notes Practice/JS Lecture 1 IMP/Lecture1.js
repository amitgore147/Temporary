console.log("Hello World!");
console.log("I am learning JS :)")

// Type	Example     Value	     	     
// Number	     25, 3.14	     	     
// String	     "hello"	     	    
// Boolean	     true, false	 	    
// Null		     null	 	     	 	 
// Undefined	 undefined	     	   
// Object	     {}, []		     	     
// Function	     function() {}	 	   

var name="Amit";
var age=24;
var price=13.33;
var x=null;
var y=undefined;
var isFollow=false;
var name=25;  //dynamic type

//or

name="Amit";
age=24;
price=13.33;
x=null;
y=undefined;
isFollow=false;
name=25;  //dynamic type

console.log(isFollow);

var fullname="Amit";
var FullName="Anjali"

console.log(fullname);
console.log(FullName);
console.log(typeof(FullName));
console.log(typeof FullName);

const students ={
    fullName:"Amit Gore",
    age:24,
    gender:"Male",
    hobbies:{
        coding:"Love it!",
        cooking:"Like to try new recipes!"
    }
}

console.log(students);
console.log(students.gender);
console.log(students['gender']);

students['age']=25;
console.log(students['age']);

students.age=25;
console.log(students.age);

const product={
    productName:"xyz",
    rating:5,
    offer:5,
    price:100
}

console.log(product);
console.log(typeof product['productName']);

//empty array
var arr = [];

//empty object
var obj = {};

//hashmap in js
let map = new Map();

// Set key-value pairs
map.set("name", "Alice");
map.set("age", 30);

// Get values
console.log(map.get("name")); // Alice
console.log(map.get("age"));  // 30

// Check existence
console.log(map.has("name")); // true

// Delete a key
map.delete("age");

// Iterate over keys and values
for (let [key, value] of map) {
  console.log(`${key} -> ${value}`);
}

// Map size
console.log(map.size); // 1
