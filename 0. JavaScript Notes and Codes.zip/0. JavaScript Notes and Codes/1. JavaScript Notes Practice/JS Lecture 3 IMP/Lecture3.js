// //for of (strings,arrays)
// str="ApnaCollege";
// size=0;
// for(let i of str){
//     console.log("i =", i);
//     size++;
// }

// console.log(size);

// //for in (objects,arrays)

// const student = {
//     name:"Amit",
//     age:25,
//     rollNo:7
// }

// for (let key in student){
//     console.log("key =",key, ", value =",student[key]);
// }

// //Practice Q1
// for(i=1;i<=100;i++){
//     if(i%2===0){
//     console.log(i);
//     }
// }

// //practice Q2
// let gameNum = 47;

// let userNum = prompt("guess gameNum:");
// while (userNum != gameNum) {
//   userNum = prompt("Wrong guess!");
// }

// alert("congrats!, that's right!!");

// //string vs template literal
// const student= {
//     fullName:"Amit Gore",
//     age:24
// }

// let info = console.log(student.fullName , "is a very good studet.", "he is", student.age, "years old")

// let infoLiteral = console.log(`${student.fullName} is a very good studet. he is ${student.age} years old`)

// //string methods

// let sentence1 = "My name is Amit Gore. Amit Gore you are best.";
// let sentence2 = "My goal is to be successfull";

// // console.log(sentence.toUpperCase());
// // console.log(sentence.toLowerCase());
// // console.log(sentence.trim());
// // console.log(sentence.slice(11,20));  //11 inclusive, 20 exclusive (means 11-19 will get printed)
// // console.log(sentence1.concat(sentence2));
// // console.log(sentence1.replace("Amit","Anjali"));
// // console.log(sentence1.replaceAll("Amit","Anjali"));
// console.log(sentence1.charAt(1));

//Practice Q1
// let fullName = prompt("please enter your full name :");
// let username = fullName.replace(" ", "");
// alert(`your user name is : @${username.toLowerCase()}${fullName.length} `);
