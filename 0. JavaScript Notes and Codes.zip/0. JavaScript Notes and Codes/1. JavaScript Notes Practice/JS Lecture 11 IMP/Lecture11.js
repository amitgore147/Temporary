// const student = {
//   fullName: "Amit Gore",
//   marks: 94.4,
//   printMarks: function () {
//     console.log("marks = ", this.marks);
//   },
//   //or we can write functions without keys also in js
//   //   printMarks() {
//   //     console.log("marks = ", this.marks);
//   //   },
// };

// const employee = {
//   calcTax() {
//     console.log("tax rate is 10%");
//   },
//   fullName: "Amit Gore",
//   marks: 94.4,
// };
// console.log(employee);

// const karanArjun = {
//   salary: 50000,
//   calcTax() {
//     console.log("tax rate is 20%");
//   },
// };

// karanArjun.__proto__ = employee;

// class ToyotaCar {
//   brand;
//   mileage;
//   constructor (brand, mileage) {
//     console.log("creating new object");
//     this.brand=brand;
//     this.mileage = mileage;
//   }
//   start() {
//     console.log("start");
//   }
//   stop() {
//     console.log("stop");
//   }

//   //   setBrand(brand) {
//   //     this.brand = brand;
//   //   }
// }

// let fortuner = new ToyotaCar("fortuner", 10); //constructor
// console.log(fortuner);
// let lexus = new ToyotaCar("lexus", 12); //constructor
// console.log(lexus);

// class Parent {
//   hello() {
//     console.log("hello");
//   }
// }

// class Child extends Parent {}

// let obj = new Child();

// class Person {
//   constructor() {
//     this.species = "homo sapiens";
//   }

//   eat() {
//     console.log("eat");
//   }
//   sleep() {
//     console.log("sleep");
//   }
//   work() {
//     console.log("do nothing");
//   }
// }

// class Engineer extends Person {
//   work() {
//     console.log("solve problems, build something");
//   }
// }

// let engObj = new Engineer();

// class Person {
//   constructor() {
//     console.log("enter parent constructor");
//     this.species = "homo sapiens";
//   }

//   eat() {
//     console.log("eat");
//   }
// }

// class Engineer extends Person {
//   constructor(branch) {
//     console.log("enter child constructor");
//     super(); //to invoke parent class constructor
//     this.branch = branch;
//     console.log("exit child constructor");
//   }

//   work() {
//     console.log("solve problems, build something");
//   }
// }

// let engObj = new Engineer("Civil Engineer");

// class Person {
//   constructor(name) {
//     this.species = "homo sapiens";
//     this.name = name;
//   }

//   eat() {
//     console.log("eat");
//   }
// }

// class Engineer extends Person {
//   constructor(name) {
//     super(name); //to invoke parent class constructor
//   }

//   work() {
//     super.eat();
//     console.log("solve problems, build something");
//   }
// }

// let engObj = new Engineer("Amit Gore");

//Practice Q1
// let DATA = "secret information";

// class User {
//   name;
//   email;
//   constructor(name, email) {
//     this.name = name;
//     this.email = email;
//   }

//   viewData() {
//     console.log("data =", DATA);
//   }
// }

// let user1 = new User("Amit Gore", "amitgore@gmail.com");
// user1.viewData();

//Practice Q2
// let DATA = "secret information";

// class User {
//   name;
//   email;
//   constructor(name, email) {
//     this.name = name;
//     this.email = email;
//   }

//   viewData() {
//     console.log("data =", DATA);
//   }
// }

// class Admin extends User {
//     constructor(name,email){
//         super(name,email);
//     }
//   editData() {
//     DATA = "sensitive information";
//   }
// }

// let admin1 = new Admin("No One", "noone@gmail.com");
// admin1.editData();
// admin1.viewData();


//error handling
let a = 5;
let b = 10;

console.log("a = ",a);
console.log("b = ", b);

console.log("a+b = ", a + b);
console.log("a+b = ", a + b);
try{
    console.log("a+b = ", a + c);
}
catch(err){
    console.log("error = ",err)
}

console.log("a+b = ", a + b);
console.log("a+b = ", a + b);