//---------------------------------------------------- DOM --------------------------------------------------------

// console.log("hello");
// window.console.log("hello")  //both are same 

// console.log(window);
// console.log(window.document);

// let heading = document.getElementsByTagName("h2");
// console.log(heading);
// console.log(heading[0].innerText);

// heading[0].innerText="Hello";
// console.log(heading[0].innerText);


let heading = document.getElementById("js");
console.log(heading);
console.dir(heading);

heading.innerText="Hello!!!"
console.log(heading.innerText);









