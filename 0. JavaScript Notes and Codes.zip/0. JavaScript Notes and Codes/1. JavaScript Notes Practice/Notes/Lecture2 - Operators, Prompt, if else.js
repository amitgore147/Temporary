//---------------------------------------------------- Comment --------------------------------------------------------

//This is a comment
console.log("Hello");

//---------------------------------------------------- Operators --------------------------------------------------------

//operators
//arthmetic +,-,*,/,%
let a = 15;
let b = 10;
console.log("a =", a, "& b=", b);
console.log("a + b =", a + b);
console.log("a - b =", a - b);
console.log("a * b =", a * b);
console.log("a / b =", a / b);
console.log("a % b =", a % b);
console.log("a^b =", a ** b);

//unary ++,--
let c = 15;

c++;
console.log(c);

//---------------------------------------------------- Prompt, if else --------------------------------------------------------

//prompt
// let nam = prompt("Enter your Name");
// alert("Welcome " + nam);
// console.log(nam);

let num = prompt("enter a number");
if(num%5===0){
    console.log("multiple of 5");
}
else{
    console.log("not a multiple of 5");
}
