//---------------------------------------------------- Object --------------------------------------------------------

// const student = {
//     fullname:"Amit",
//     age: 40,
//     gender:"Male",
//     gf:true,
//     smart:true
// }
// console.log(student);

//---------------------------------------------------- Object Methods --------------------------------------------------------

// Object.keys(student)      // Returns array of property names
// Object.values(student)    // Returns array of property values
// Object.entries(student)   // Returns array of [key, value] pairs
// Object.assign(target, source) // Copies values from source to target

// let serialized = JSON.stringify(user);                  // beautify JSON.stringify(user, null, 2); 
// console.log(serialized); // '{"name":"Alice","age":25}'

// let deserialized = JSON.parse(serialized);
// console.log(deserialized.name); // "Alice"


//---------------------------------------------------- Array --------------------------------------------------------

// //Arrays
// let arr=[1,2,3,5,6];
// console.log(arr);
// console.log(arr.length);

// //looping
// let arr=[1,2,3,5,6];
// for(let i=0; i<arr.length;i++){
//     console.log(arr[i]);
// }

// let heroes=["ak", 'sk', 'rr'];
// for(let hero of heroes){
//     console.log(hero);
// }

// //PQ1
// let marks = [100,50,50,200,300];

// total=0;
// for(i=0;i<marks.length;i++){
//     total=total+marks[i];
// }

// // for(let mark of marks){
// //     total+=mark;
// // }

// avg=total/marks.length;
// console.log(avg);

// //PQ2
// let prices = [100,50,50,200,300];

// totalafteroffer=0;
// offer=10;

// for(let price of prices){
//     totalafteroffer = totalafteroffer + price*(1-(offer/100)) ;
// }

// average=totalafteroffer/prices.length;

// console.log(average);

//---------------------------------------------------- Array Methods --------------------------------------------------------

// //array methods
// let prices1 = [100,50,50,200,300];

// let prices2 = [100,50,50,200,300];
// // console.log(prices1.push(100));
// // console.log(prices1.pop());
// // console.log(prices1.toString());
// // console.log(prices1.concat(prices2));
// // console.log(prices1.unshift(50));
// // console.log(prices1.shift());
// // console.log(prices1.slice(2,4));
// // console.log(prices1.splice(1,2)); //splice(add,remove,replace)
// // console.log(prices1);

//PQ1

let componies=["Bloomberg","Microsoft","Uber","Google","IBM","Netflix"];


console.log(componies);
componies.push("Amazon");
console.log(componies);














