// console.log("one");
// console.log("two");
// console.log("three");

// function hello() {
//   console.log("hello");
// }

// setTimeout(hello, 2000);
//or
// setTimeout(() => {
//   console.log("hello");
// }, 2000);
// //or
// setTimeout(function hello() {
//   console.log("hello");
// }, 2000);

// console.log("four");
// console.log("five");

//callback
// function sum(a, b) {
//   console.log(a + b);
// }

// function multiply(a, b) {
//   console.log(a * b);
// }

// function calculator(a, b, callBack) {
//   callBack(a, b);
// }

// calculator(4, 2, sum);
// calculator(4, 2, multiply);

// calculator(4, 2, (a, b) => {
//   console.log(a - b);
// });

// function hello() {
//   console.log("hello");
// }

// setTimeout(hello, 2000);

//callback hell
// function getData(dataId, getNextData) {
//   setTimeout(() => {
//     console.log("Data", dataId);
//     if (getNextData) {
//       getNextData();
//     }
//   }, 3000);
// }

// //callback hell

// getData(1, () => {
//   console.log("getting data2.....");
//   getData(2, () => {
//     console.log("getting data3.....");
//     getData(3, () => {
//       console.log("getting data4.....");
//       getData(4);
//     });
//   });
// });

//promise when we dont call reject or resolve function the state will be pending

// let jsPromise = new Promise((resolve, reject) => {
//   reject("error ");
// });

// const getPromise = () => {
//   return new Promise((resolve, reject) => {
//     console.log("I am a promise");
//     // resolve("success");
//     reject("error occured");
//   });
// };

// let promise = getPromise();
// //then and catch only execute when promise state is fullfilled/rejected not at pending state
// promise.then((res) => {
//   console.log("promise fullfilled = ",res);
// });
// promise.catch((err) => {
//   console.log("promise rejected = ",err);
// });

// function asynFunc() {
//   return new Promise((resolve, reject) => {
//     setTimeout(() => {
//       console.log("some data1");
//       resolve("success");
//     }, 3000);
//   });
// }

// function asynFunc2() {
//   return new Promise((resolve, reject) => {
//     setTimeout(() => {
//       console.log("some data2");
//       resolve("success");
//     }, 6000);
//   });
// }

// console.log("fetching data1");
// let p1 = asynFunc();
// p1.then((res) => {
//   console.log("fullfilled = ", res);
// });

// console.log("fetching data2");
// let p2 = asynFunc2();
// p2.then((res) => {
//   console.log("fullfilled = ", res);
// });

// console.log("fetching data1");
// let p1 = asynFunc();
// p1.then((res) => {
//   console.log("fetching data2");
//   let p2 = asynFunc2();
//   p2.then((res) => {
//   });
// });

//or

// console.log("fetching data1");
// asynFunc().then((res) => {
//   console.log("fetching data2");
//   asynFunc2().then((res) => {});
// });

//callback hell resolve using promise
// function getData(dataId) {
//   return new Promise((resolve, reject) => {
//     setTimeout(() => {
//       console.log("Data", dataId);
//       resolve("success");
//     }, 3000);
//   });
// }

// getData(1, () => {
//   console.log("getting data2.....");
//   getData(2, () => {
//     console.log("getting data3.....");
//     getData(3, () => {
//       console.log("getting data4.....");
//       getData(4);
//     });
//   });
// });

//promise chain
// let p1 = getData(1);
// p1.then((res) => {
//   console.log(res);
//   getData(2).then((res) => {
//     console.log(res);
//   });
// });

// getData(1)
//   .then((res) => {
//     return getData(2);
//   })
//   .then((res) => {
//     return getData(3);
//   })
//   .then((res) => {
//     console.log(res);
//   });

// console.log("getting data1.....");
// getData(1)
//   .then((res) => {
//     console.log("getting data2.....");
//     return getData(2);
//   })
//   .then((res) => {
//     console.log("getting data3.....");
//     return getData(3);
//   })
//   .then((res) => {
//     console.log(res);
//   });

//async await
// async function hello() {
//   console.log("hello");
// }

// function api() {
//   return new Promise((resolve, reject) => {
//     setTimeout(() => {
//       console.log("weather data");
//       resolve(200);
//     },2000);
//   });
// }

// async function getWeatherData(){
//     await api();//first
//     await api();//second
// }

function getData(dataId) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      console.log("Data", dataId);
      resolve("success");
    }, 3000);
  });
}

// async function getAllData(){
//     console.log("getting data1.....");
//     await getData(1);
//     console.log("getting data2.....");
//     await getData(2);
//     console.log("getting data3.....");
//     await getData(3);
// }

//or
//IIFE (func)(); function should not have name

(async function () {
  console.log("getting data1.....");
  await getData(1);
  console.log("getting data2.....");
  await getData(2);
  console.log("getting data3.....");
  await getData(3);
})();
